const WebSocket = require('ws');
const http = require('http');

const server = http.createServer();
const wss = new WebSocket.Server({ server });

let users = new Map();

wss.on('connection', (ws) => {
    ws.on('message', (message) => {
        const data = JSON.parse(message);

        switch (data.type) {
            case 'login':
                users.set(ws, data.username);
                broadcast({ type: 'userUpdate', users: Array.from(users.values()) });
                break;

            case 'message':
                broadcast({
                    type: 'message',
                    username: data.username,
                    content: data.content,
                });
                break;
        }
    });

    ws.on('close', () => {
        users.delete(ws);
        broadcast({ type: 'userUpdate', users: Array.from(users.values()) });
    });
});

function broadcast(data) {
    const message = JSON.stringify(data);
    users.forEach((_, ws) => {
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(message);
        }
    });
}

server.listen(3000, () => console.log('Server running on port 3000'));
