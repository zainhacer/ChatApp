const socket = new WebSocket('ws://localhost:3000');

const username = prompt('Enter your username:');
socket.onopen = () => {
    socket.send(JSON.stringify({ type: 'login', username }));
};

const userList = document.getElementById('user-list');
const messageContainer = document.getElementById('message-container');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');

sendButton.addEventListener('click', () => {
    const content = messageInput.value.trim();
    if (content) {
        socket.send(JSON.stringify({ type: 'message', username, content }));
        messageInput.value = '';
    }
});

socket.onmessage = (event) => {
    const data = JSON.parse(event.data);

    switch (data.type) {
        case 'userUpdate':
            userList.innerHTML = '';
            data.users.forEach(user => {
                const li = document.createElement('li');
                li.textContent = user;
                userList.appendChild(li);
            });
            break;

        case 'message':
            const message = document.createElement('div');
            message.className = 'message';
            message.innerHTML = `<strong>${data.username}:</strong> ${data.content}`;
            messageContainer.appendChild(message);
            messageContainer.scrollTop = messageContainer.scrollHeight;
            break;
    }
};
